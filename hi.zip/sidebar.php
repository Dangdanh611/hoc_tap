<!-- sidebar.php -->
<div class="flex h-screen">
    <!-- Sidebar -->
    <div id="sidebar" class="w-64 bg-gray-800 text-white p-5 transition-all duration-300">
        <h2 class="text-xl font-bold mb-5">Dashboard</h2>

        <!-- Menu -->
        <ul>
            <li>
                <a href="index.php" class="block p-2 rounded hover:bg-gray-700">Trang chủ</a>
            </li>
            <li>
                <a href="add_schedule.php" class="block p-2 rounded hover:bg-gray-700">Thêm lịch học</a>
            </li>
            <li>
                <a href="add_word.php" class="block p-2 rounded hover:bg-gray-700">Thêm từ vựng</a>
            </li>

            <!-- Dropdown Menu -->
            <li class="relative">
                <button onclick="toggleDropdown()" class="w-full text-left p-2 rounded hover:bg-gray-700 flex justify-between">
                    Quản lý <span>▼</span>
                </button>
                <ul id="dropdown-menu" class="hidden bg-gray-700 rounded mt-1">
                    <li><a href="manage_schedule.php" class="block p-2 hover:bg-gray-600">Lịch học</a></li>
                    <li><a href="manage_word.php" class="block p-2 hover:bg-gray-600">Từ vựng</a></li>
                </ul>
            </li>

            <!-- Dark Mode Toggle -->
            <li class="mt-5">
                <button onclick="toggleDarkMode()" class="w-full p-2 rounded bg-gray-600 hover:bg-gray-500">
                    🌙 / ☀️ Chế độ sáng tối
                </button>
            </li>
        </ul>
    </div>

    <!-- Content Area -->
    <div class="flex-1 p-5 transition-all duration-300">
        <button onclick="toggleSidebar()" class="p-2 bg-gray-700 text-white rounded">☰</button>
        <div id="content">
            <!-- Nội dung chính của trang -->
        </div>
    </div>
</div>

<script>
    function toggleSidebar() {
        document.getElementById("sidebar").classList.toggle("w-20");
    }

    function toggleDropdown() {
        document.getElementById("dropdown-menu").classList.toggle("hidden");
    }

    function toggleDarkMode() {
        document.body.classList.toggle("bg-gray-900");
        document.body.classList.toggle("text-white");
    }
</script>
